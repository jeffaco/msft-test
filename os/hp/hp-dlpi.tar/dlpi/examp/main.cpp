#include <unistd.h>
#include <fcntl.h>
#include <sys/dlpi.h>
#include <sys/mib.h>
#include <stdio.h>
#include <stdlib.h>

int dl_open(int ppa, char *ebuf, char * dev = 0);
int dl_get_stats(int fd, char *bufp, char *ebuf);

int main(int argc, char ** argv)
{
    char ebuf[256]; 
    char * dev = 0;
    int ppa = 0; 

    if(argc >= 2)
        dev = argv[1];

    if(argc >= 3)
        ppa = atoi(argv[2]); 

    int fd = dl_open(ppa, ebuf, dev); 
    if(fd < 0)
    {
        printf("Error returned by dl_open()\n"); 
        return 1; 
    }

    char buf[512];

    if(dl_get_stats(fd, buf, ebuf) >= 0)
    {
        dl_get_statistics_ack_t * p_ack = (dl_get_statistics_ack_t *)&buf[0]; 
        mib_ifEntry * stats = (mib_ifEntry *)((char*)(buf + p_ack->dl_stat_offset));
        printf("stats->ifDescr: %s\n", stats->ifDescr);
        printf("stats->ifInOctets: %d\n", stats->ifInOctets);
        printf("stats->ifOutOctets: %d\n", stats->ifOutOctets);
        close(fd); 
        return 2; 
    }
    
    printf("no");

    close(fd);
    return 0;
}
