#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <sys/poll.h>

#include "scxdlpi.h"

    #define INSAP 22 
    #define OUTSAP 24 
    #define CONTROL 1 
    #define DATA 2 
    #define BOTH 3 
    #define INTERRUPT 4 
    #define ERROR 128 
    #define MAX_PPA 10


typedef struct {
    int ifIndex;
    char ifDescr[64];
    int ifType;
    int ifMtu;
    gauge ifSpeed;
    unsigned char ifPhysAddress[8];
    int ifAdmin;
    int ifOper;
    TimeTicks ifLastChange;
    size_t ifInOctets;
    size_t ifInUcastPkts;
    size_t ifInNUcastPkts;
    size_t ifInDiscards;
    size_t ifInErrors;
    size_t ifInUnknownProtos;
    size_t ifOutOctets;
    size_t ifOutUcastPkts;
    size_t ifOutNUcastPkts;
    size_t ifOutDiscards;
    size_t ifOutErrors;
    gauge ifOutQlen;
    int ifSpecific;
} mib_ifEntry;


int test();
int main(int, char **)
{
    test();
    return 0;
}

int test()
{
    int fd;
    int ppa;
    u_char stats[200];
    int i;
    
    char **device;
    
    // Should work for AIX and SUN, but using their device files in place of /dev/dlpi
    if (ERROR != dlpi::openDLPI("/dev/dlpi", 0, &fd))
    {
        if (ERROR != dlpi::bindDLPI(fd, INSAP, stats))
        {
            close(fd);
            return 0;
        }
        close(fd);
    }
    return -1;
}

