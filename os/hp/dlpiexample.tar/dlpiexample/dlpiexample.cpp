#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string>
#include <iostream>
#include <sys/stropts.h>
#include <sys/dlpi.h>
#include <sys/dlpi_ext.h>

using namespace std;

string bytesToHex(const u_char * addr, size_t len);

int main()
{

  int dlpi_fd = open("/dev/dlpi", O_RDWR);
  if (dlpi_fd == -1)
    {
      cerr << "Unable to open /dev/dlpi" << endl;
      return 1;
    }
  
  // prepare to send a message requesting the full list of ppa's
  int errorVal;

  // make sure this buffer is large enough to hold all the data being sent back
  // also make the buffer align the data properly by composing it of u_longs
  struct strbuf messageHolder;
  u_long buffer[1000 * sizeof(dl_hp_ppa_info_t)];
  messageHolder.buf = (char*)buffer;
  messageHolder.maxlen = sizeof(buffer);
  messageHolder.len = 0;

  int flags = 0;

  // set the request value in the buffer
  dl_hp_ppa_req_t * reqMessage = (dl_hp_ppa_req_t *)messageHolder.buf;
  reqMessage->dl_primitive = DL_HP_PPA_REQ;
  messageHolder.len = sizeof(dl_hp_ppa_req_t);

  // send the message asking for the ppa list
  errorVal = putmsg(dlpi_fd, &messageHolder, NULL, flags);
  
  if (errorVal == -1)
    {
      cerr << "Error putting DL_HP_PPA_REQ message" << endl;
      perror("Error");
      return 1;
    }

  // get the response
  dl_hp_ppa_ack_t * ackMessage = (dl_hp_ppa_ack_t *)messageHolder.buf;
  messageHolder.len = sizeof(dl_hp_ppa_ack_t);

  errorVal = getmsg(dlpi_fd, &messageHolder, NULL, &flags);

  if (errorVal == -1)
    {
      cerr << "Error getting DL_HP_PPA_ACK message" << endl;
      perror("Error");
      return 1;
    }

  if (ackMessage->dl_primitive != DL_HP_PPA_ACK)
    {
      cerr << "Error: response message is not DL_HP_PPA_ACK" << endl;
      perror("Error");
      return 1;
    }


  // set up the dl_hp_ppa_info_t array, and then print every field out for every element

  dl_hp_ppa_info_t * ppaArray = (dl_hp_ppa_info_t *)(ackMessage->dl_offset + messageHolder.buf);
  int numInArray = ackMessage->dl_count;

  dl_hp_ppa_info_t * permArray = (dl_hp_ppa_info_t *)calloc(numInArray,sizeof(dl_hp_ppa_info_t));
  memcpy(permArray, ppaArray, numInArray * sizeof(dl_hp_ppa_info_t));
  
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
  cout << "Enumeration of PPAs" << endl;
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
  cout << "NEXT_OFFSET | PPA | HW_PATH | MAC_TYPE | PHYS_ADDR | ADDR_LENGTH | MJR_NUM | NAME | INSTANCE_NUM | MTU | HDW_STATE | MODULE_ID_1 | MODULE_ID_2 | ARPMOD_NAME | NMID | RESERVED1 | RESERVED2" << endl;

  for (int curElem = 0; curElem < numInArray; curElem++)
    {
      cout << permArray[curElem].dl_next_offset << " | "
           << permArray[curElem].dl_ppa << " | "
           << permArray[curElem].dl_hw_path << " | "
           << permArray[curElem].dl_mac_type << " | "
           << bytesToHex(permArray[curElem].dl_phys_addr, permArray[curElem].dl_addr_length) << " | "
           << permArray[curElem].dl_addr_length << " | "
           << permArray[curElem].dl_mjr_num << " | "
           << permArray[curElem].dl_name << " | "
           << permArray[curElem].dl_instance_num << " | "
           << permArray[curElem].dl_mtu << " | "
           << permArray[curElem].dl_hdw_state << " | "
           << permArray[curElem].dl_module_id_1 << " | "
           << permArray[curElem].dl_module_id_2 << " | "
           << permArray[curElem].dl_arpmod_name << " | "
           << permArray[curElem].dl_nmid << " | "
           << permArray[curElem].dl_reserved1 << " | "
           << permArray[curElem].dl_reserved2 << " | "
           << endl;
    }


  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
  cout << "Stats for Each PPA" << endl;
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
 
  // for each PPA, get mib_ifentry
  for (int curVal = 0; curVal < numInArray; curVal++)
    {
      


      // attach and bind ppa to this stream for stats purposes
      dl_attach_req_t * attachReq = (dl_attach_req_t *)messageHolder.buf;
      attachReq->dl_primitive = DL_ATTACH_REQ;
      attachReq->dl_ppa = permArray[curVal].dl_ppa;
      messageHolder.len = sizeof(dl_attach_req_t);
      errorVal = putmsg(dlpi_fd, &messageHolder, NULL, 0);
      if (errorVal == -1)
        {
          cerr << "Error putting DL_ATTACH_REQ message " << endl;
          perror("Error");
          return 1;
        }
      
      // accept a dl_ok
      dl_ok_ack_t * okAck = (dl_ok_ack_t *)messageHolder.buf;
      messageHolder.len = sizeof(dl_ok_ack_t);
      
      errorVal = getmsg(dlpi_fd, &messageHolder, NULL, &flags);
      if (errorVal == -1)
        {
          cerr << "Error getting expected DL_OK_ACK message " << endl;
          perror("Error");
          return 1;
        }
      
      if (okAck->dl_primitive != DL_OK_ACK)
        {
          cerr << "Eror attaching to PPA: " << permArray[curVal].dl_ppa << endl;
          perror("Error");
          continue;

        }
      
      
      
      // dl bind req
      dl_bind_req_t * bindReq = (dl_bind_req_t *)messageHolder.buf;
      memset((char*)bindReq, 0, sizeof(dl_bind_req_t));
      bindReq->dl_primitive = DL_BIND_REQ;
      bindReq->dl_sap = 22;
      bindReq->dl_service_mode = DL_CODLS;
      bindReq->dl_max_conind = 1;
      messageHolder.len = sizeof(dl_bind_req_t);
      
      errorVal = putmsg(dlpi_fd, &messageHolder, NULL, 0);
      
      if (errorVal == -1)
        {
          cerr << "Error putting DL_BIND_REQ message " << endl;
          perror("Error");
          return 1;
        }
      
      
      // dl bind ack
      dl_bind_ack_t * bindAck = (dl_bind_ack_t *)messageHolder.buf;
      messageHolder.len = sizeof(dl_bind_ack_t);
      flags = 0;
      errorVal = getmsg(dlpi_fd, &messageHolder, NULL, &flags);
      
      
      if (errorVal == -1)
        {
          cerr << "Error getting DL_BIND_ACK message " << endl;
          perror("Error");
          return 1;
        }

      if (bindAck->dl_primitive == DL_ERROR_ACK)
        {
          cerr << "Error binding to PPA: " << permArray[curVal].dl_ppa << endl;
          perror("Error");
          continue;

        }
      
      if (bindAck->dl_primitive != DL_BIND_ACK)
        {
          cerr << "Error dl_primitive does not match DL_BIND_ACK " << endl;
          cerr << "dl_primitive is: " << bindAck->dl_primitive << endl;
          perror("Error");
          return 1;
        } 
      
      
      // get statistics
      dl_get_statistics_req_t * statReq = (dl_get_statistics_req_t *)messageHolder.buf;
      statReq->dl_primitive = DL_GET_STATISTICS_REQ;
      messageHolder.len = sizeof(dl_get_statistics_req_t);
      errorVal = putmsg(dlpi_fd, &messageHolder, NULL, 0);
      if (errorVal == -1)
        {
          cerr << "Error putting DL_GET_STATISTICS_REQ message " << endl;
          perror("Error");
          return 1;
        }
      
      dl_get_statistics_ack_t * statAck = (dl_get_statistics_ack_t *)messageHolder.buf;
      messageHolder.len = sizeof(dl_get_statistics_ack_t);
      errorVal = getmsg(dlpi_fd, &messageHolder, NULL, &flags);
      
      if (errorVal == -1)
        {
          cerr << "Error getting DL_GET_STATISTICS_ACK message " << endl;
          perror("Error");
          return 1;
        }
      
      if (statAck->dl_primitive != DL_GET_STATISTICS_ACK)
        {
          cerr << "Error dl_primitive does not match DL_GET_STATISTICS_ACK " << endl;
          perror("Error");
          return 1;
        }
      
      cout << "===========================================================================" << endl;
      cout << "PPA: " << permArray[curVal].dl_ppa << endl;
      cout << "===========================================================================" << endl;
      
      mib_ifEntry * stats = (mib_ifEntry *)(statAck->dl_stat_offset + messageHolder.buf);
      
      cout << "IfIndex = " << stats->ifIndex << endl; 
      cout << " Descr = " << stats->ifDescr << endl; 
      cout << " Type = " << stats->ifType << endl; 
      cout << " MTU = " << stats->ifMtu << endl; 
      cout << " Admin Status = " << stats->ifAdmin << endl; 
      cout << " Oper Status = " << stats->ifOper << endl; 
      cout << " Phys Addr = 0x"; 
      cout << bytesToHex(stats->ifPhysAddress.o_bytes, stats->ifPhysAddress.o_length) << endl; 
      cout << "\n Phys. Addr len = " << stats->ifPhysAddress.o_length << endl;
      cout << " InUcastPkts = " << stats->ifInUcastPkts << endl; 
      cout << " InNUcastPkts = " << stats->ifInNUcastPkts << endl; 
      cout << " InErrors = " << stats->ifInErrors << endl; 
      cout << " OutUcastPkts = " << stats->ifOutUcastPkts << endl; 
      cout << " OutNUcastPkts = " << stats->ifOutNUcastPkts << endl; 
      cout << " OutErrors = " << stats->ifOutErrors << endl; 
      cout << " OutQlen = " << stats->ifOutQlen << endl; 
      





      /*
  // test out DL_HP_INFO_ACK
  dl_hp_info_req_t * infoReq = (dl_hp_info_req_t *)messageHolder.buf;
  infoReq->dl_primitive = DL_HP_INFO_REQ;
  messageHolder.len = sizeof(dl_hp_info_req_t);
  cerr << "here1" <<endl;
  errorVal = putmsg(dlpi_fd, &messageHolder, NULL, 0);
  cerr << "here2" <<endl;
  if (errorVal == -1)
    {
      cerr << "Error putting DL_HP_INFO_REQ message " << endl;
      perror("Error");
      return 1;
    }

  dl_hp_info_ack_t * infoAck = (dl_hp_info_ack_t *)messageHolder.buf;
  messageHolder.len = sizeof(dl_hp_info_ack_t);
  cerr << "here3" <<endl;
  errorVal = getmsg(dlpi_fd, &messageHolder, NULL, &flags);
  cerr << "here4" <<endl;
  if (errorVal == -1)
    {
      cerr << "Error getting DL_HP_INFO_ACK message " << endl;
      perror("Error");
      return 1;
    }  
  

  cout << infoAck->dl_primitive << "|";
  cout << infoAck->dl_mem_fails << "|";
  cout << infoAck->dl_queue_fails << "|";
  cout << infoAck->dl_ack_to << "|";
  cout << infoAck->dl_p_to << "|";
  cout << infoAck->dl_rej_to << "|";
  cout << infoAck->dl_busy_to << "|";
  cout << infoAck->dl_send_ack_to << "|";
  cout << infoAck->dl_ack_to_cnt << "|";
  cout << infoAck->dl_p_to_cnt << "|";
  cout << infoAck->dl_rej_to_cnt << "|";
  cout << infoAck->dl_busy_to_cnt << "|";
  cout << infoAck->dl_local_win << "|";
  cout << infoAck->dl_remote_win << "|";
  cout << infoAck->dl_i_pkts_in << "|";
  cout << infoAck->dl_i_pkts_in_oos << "|";
  cout << infoAck->dl_i_pkts_in_drop << "|";
  cout << infoAck->dl_i_pkts_out << "|";
  cout << infoAck->dl_i_pkts_retrans << "|";
  cout << infoAck->dl_s_pkts_in << "|";
  cout << infoAck->dl_s_pkts_out << "|";
  cout << infoAck->dl_u_pkts_in << "|";
  cout << infoAck->dl_u_pkts_out << "|";
  cout << infoAck->dl_bad_pkts << "|";
  cout << infoAck->dl_retry_cnt << "|";
  cout << infoAck->dl_max_retry_cnt << "|";
  cout << infoAck->dl_max_retries << "|";
  cout << infoAck->dl_ack_thresh << "|";
  cout << infoAck->dl_remote_busy_cnt << "|";
  cout << infoAck->dl_hw_req_fails << "|";
  cout << endl;

*/



      // unbind
      dl_unbind_req_t * unbindReq = (dl_unbind_req_t *)messageHolder.buf;
      unbindReq->dl_primitive = DL_UNBIND_REQ;
      messageHolder.len = sizeof(dl_unbind_req_t);
      
      errorVal = putmsg(dlpi_fd, &messageHolder, NULL, 0);
      
      if (errorVal == -1)
        {
          cerr << "Error putting DL_UNBIND_REQ message " << endl;
          perror("Error");
          return 1;
        }
      
      // take OK_ACK
      dl_ok_ack_t * okAck2 = (dl_ok_ack_t *)messageHolder.buf;
      messageHolder.len = sizeof(dl_ok_ack_t);
      
      errorVal = getmsg(dlpi_fd, &messageHolder, NULL, &flags);
  
      if (errorVal == -1)
        {
          cerr << "Error getting DL_OK_ACK message " << endl;
          perror("Error");
          return 1;
        } 
      if (okAck2->dl_primitive != DL_OK_ACK)
        {
          cerr << "Expecting DL_OK_ACK (2), didn't get" << endl;
          perror("Error");
          return 1;
        }
      
      // detach
      dl_detach_req_t * detachReq = (dl_detach_req_t *)messageHolder.buf;
      detachReq->dl_primitive = DL_DETACH_REQ;
      messageHolder.len = sizeof(dl_detach_req_t);
      
      errorVal = putmsg(dlpi_fd, &messageHolder, NULL, 0);
      
      if (errorVal == -1)
        {
          cerr << "Error putting DL_DETACH_REQ message " << endl;
          perror("Error");
          return 1;
        }
      

      // take OK_ACK
      dl_ok_ack_t * okAck3 = (dl_ok_ack_t *)messageHolder.buf;
      messageHolder.len = sizeof(dl_ok_ack_t);
      
      errorVal = getmsg(dlpi_fd, &messageHolder, NULL, &flags);

      if (errorVal == -1)
        {
          cerr << "Error getting DL_OK_ACK message " << endl;
          perror("Error");
          return 1;
        } 
      if (okAck3->dl_primitive != DL_OK_ACK)
        {
          cerr << "Expecting DL_OK_ACK (3), didn't get" << endl;
          perror("Error");
          return 1;
        }
      
    }
  

  free(permArray);
  close(dlpi_fd);
    

  return 0;

}


// convert mac addr (and the like) to proper hex string
string bytesToHex(const u_char * addr, size_t len = 6)
{
  char buf[1024];

  for (int i = 0; i < len; i++)
    {
      snprintf(buf+2*i, 1024-2*i, "%02X", addr[i]);
    }

  
  return string(buf);
}


