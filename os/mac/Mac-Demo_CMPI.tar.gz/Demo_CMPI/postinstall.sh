#!/bin/sh

restart_services() {
  launchctl unload -w /Library/LaunchDaemons/com.microsoft.scx-cimd.plist \
      /Library/LaunchDaemons/com.microsoft.scx-wsmand.plist
  launchctl load -w /Library/LaunchDaemons/com.microsoft.scx-cimd.plist \
      /Library/LaunchDaemons/com.microsoft.scx-wsmand.plist
}



#
# Main section
#

# Set up our library path for purposes of running utilities

export DYLD_LIBRARY_PATH=/usr/libexec/microsoft/scx/lib:/usr/libexec/microsoft/scx/lib/providers:/usr/libexec/microsoft/scx/lib/providers/ext

# Compile new classes into namespace

/usr/libexec/microsoft/scx/bin/tools/scxcimmof -nroot/PG_InterOp /usr/libexec/microsoft/scx/lib/providers/ext/provider_r.mof

# Restart services

echo "Restarting Services ..."
restart_services

exit 0
