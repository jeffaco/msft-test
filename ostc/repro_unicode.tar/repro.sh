#!/bin/sh
yes m� alxapfs34� -� > /dev/null 2>&1 &

sleep 2
ps -ef | grep yes
scxadmin -restart
/opt/microsoft/scx/bin/tools/scxcimcli ei -n root/scx SCX_UnixProcess
killall yes > /dev/null
