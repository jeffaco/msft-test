#include <stdio.h>
#include <ctype.h>

int main()
{
	char c = '\xC2';
	int i = -1;

	printf("%x\n\n", isdigit(c));
}
